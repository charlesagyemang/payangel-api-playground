[![npm version](https://img.shields.io/npm/v/payangel.svg)](https://www.npmjs.com/package/payangel)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Node Version](https://img.shields.io/node/v/payangel.svg)](https://nodejs.org)

# PayAngel Node.js SDK

Official Node.js SDK for the [PayAngel](https://payangel.com) payments API — send and collect money across Africa (Ghana, Nigeria, Kenya, South Africa).

**TypeScript-first. Zero runtime dependencies. Works with Node 16+.**

Built for developers familiar with Stripe, Paystack, and Flutterwave — the API surface will feel immediately familiar.

---

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [Authentication](#authentication)
- [Environments](#environments)
- [Disbursement](#disbursement)
  - [Send Money (Bank Transfer)](#send-money-bank-transfer)
  - [Send Money (Mobile Money)](#send-money-mobile-money)
  - [Query Transaction](#query-transaction)
  - [Account Balance](#account-balance)
  - [Bank Codes](#bank-codes)
  - [Name Check](#name-check)
- [Collection](#collection)
  - [Mobile Money Collection](#mobile-money-collection)
  - [Card Collection](#card-collection)
  - [Collection Status](#collection-status)
- [Webhooks](#webhooks)
- [Error Handling](#error-handling)
- [Normalised Response](#normalised-response)
- [TypeScript](#typescript)
- [Important Notes](#important-notes)
- [Known Limitations](#known-limitations)
- [License](#license)

---

## Installation

```bash
npm install payangel
```

```bash
yarn add payangel
```

```bash
pnpm add payangel
```

---

## Quick Start

```typescript
import { PayAngel } from "payangel";

const client = new PayAngel({
  publicKey: "your_public_key",
  secretKey: "your_secret_key",
  env: "production",
});

// Check your wallet balance
const balance = await client.disbursement.balance();
console.log(balance.data);
// [{ currency: "USD", balance: "1000.00" }]

// Get available banks in Ghana
const banks = await client.disbursement.bankCodes({ country: "GH" });
console.log(banks.data);
// { country: "Ghana", banks: [...], mobileProviders: [...] }

// Send money to a bank account
const result = await client.disbursement.send({
  transactionId: "PAY-001",
  senderFirstName: "John",
  senderLastName: "Doe",
  countryFrom: "GH",
  countryTo: "GH",
  sendingCurrency: "GHS",
  receivingCurrency: "GHS",
  destinationAmount: 100,
  beneficiaryFirstName: "Jane",
  beneficiaryLastName: "Mensah",
  transferType: "bank",
  bankAccountNumber: "1234567890",
  bankCode: "170100",
  transferReason: "Family Support",
  customerRef: "REF-001",
  callbackUrl: "https://yourserver.com/webhooks/payangel",
});

console.log(result.success);       // true
console.log(result.transactionId); // "PAY-001"
console.log(result.referenceId);   // "STA-100000000143"
console.log(result.status);        // "PENDING"
console.log(result.amount);        // 100
console.log(result.fee);           // 0
```

---

## Authentication

The SDK uses HTTP Basic Auth with your PayAngel API keys. You can find your keys at [business.payangel.com](https://business.payangel.com).

### Option A: Pass keys directly

```typescript
const client = new PayAngel({
  publicKey: "your_public_key",
  secretKey: "your_secret_key",
  env: "production",
  timeout: 30000, // optional, defaults to 30s
});
```

### Option B: Use environment variables

```bash
# .env
PAYANGEL_PUBLIC_KEY=your_public_key
PAYANGEL_SECRET_KEY=your_secret_key
PAYANGEL_ENV=production
```

```typescript
const client = new PayAngel(); // reads from env vars
```

### Config resolution priority

1. Explicit constructor argument
2. Environment variable (`PAYANGEL_PUBLIC_KEY`, `PAYANGEL_SECRET_KEY`, `PAYANGEL_ENV`)
3. Defaults (`"production"` for env, `30000` for timeout)

An `AuthenticationError` is thrown at instantiation if no keys are found.

### IP Whitelisting

PayAngel requires your server IP to be whitelisted in the portal. If you receive error code `E0014-098` ("You are not allowed to use this service"), add your server's public IP to the whitelist at [business.payangel.com](https://business.payangel.com) under your channel settings.

---

## Environments

| Environment | Domain | TLD |
|---|---|---|
| Sandbox | `https://payconnect.payangel.org` | `.org` |
| Production | `https://payconnect.payangel.com` | `.com` |

```typescript
// Sandbox (for testing)
const client = new PayAngel({ ..., env: "sandbox" });

// Production (default)
const client = new PayAngel({ ..., env: "production" });
```

> **Note:** Different TLDs — `.org` for sandbox, `.com` for production. The SDK handles this automatically based on the `env` option.

---

## Disbursement

### Send Money (Bank Transfer)

```typescript
const result = await client.disbursement.send({
  transactionId: "PAY-BANK-001",       // your unique transaction ID
  senderFirstName: "John",
  senderLastName: "Doe",
  countryFrom: "GH",
  countryTo: "GH",
  sendingCurrency: "GHS",
  receivingCurrency: "GHS",
  destinationAmount: 100,               // amount recipient receives
  beneficiaryFirstName: "Jane",
  beneficiaryLastName: "Mensah",
  transferType: "bank",
  bankAccountNumber: "1775702701014",
  bankName: "FIRST ATLANTIC BANK",
  bankBranch: "EAST LEGON",
  bankCode: "170100",                   // payangelCode from bankCodes()
  transferReason: "Family Support",
  customerRef: "REF-001",
  callbackUrl: "https://yourserver.com/webhooks/payangel",
});

// result.success       → true
// result.transactionId → "PAY-BANK-001"
// result.referenceId   → "STA-100000000143"
// result.status        → "PENDING"
// result.amount        → 100
// result.fee           → 0
// result.total         → 100
// result.currency      → "GHS"
```

#### Optional sender fields

```typescript
{
  senderMiddlename: "Michael",
  senderPhone: "+1234567890",
  senderAddress: "123 Main St",
  senderCity: "New York",
  senderNationality: "US",
  senderIDExpiry: "2028-12-31",
  sourceOfIncome: "Employment",
  beneficiaryMiddleName: "Akua",
  recipientNationality: "GH",
  receiverDOB: "1990-01-15",
  purposeDetails: "Monthly allowance",
}
```

### Send Money (Mobile Money)

```typescript
const result = await client.disbursement.send({
  transactionId: "PAY-MOMO-001",
  senderFirstName: "John",
  senderLastName: "Doe",
  countryFrom: "GH",
  countryTo: "GH",
  sendingCurrency: "GHS",
  receivingCurrency: "GHS",
  destinationAmount: 50,
  beneficiaryFirstName: "Kwame",
  beneficiaryLastName: "Asante",
  transferType: "mobile",
  mobileNetwork: "MTN",            // accepts any casing: "mtn", "MTN", "Mtn"
  mobileNumber: "0551234567",
  transferReason: "Gift",
  customerRef: "REF-002",
  callbackUrl: "https://yourserver.com/webhooks/payangel",
});
```

#### Supported mobile networks

| Input (any casing) | Disbursement sends | Collection sends |
|---|---|---|
| `"mtn"` / `"MTN"` | `"MTN"` | `"mtn"` |
| `"telecel"` / `"vodafone"` | `"Telecel"` | `"telecel"` |
| `"airteltigo"` / `"at"` | `"AirtelTigo"` | `"at"` |

The SDK normalises `mobileNetwork` automatically — you never need to worry about casing.

### Query Transaction

```typescript
const status = await client.disbursement.query("PAY-BANK-001");

console.log(status.status);        // "SUCCESS" | "PENDING" | "PROCESSING" | "FAILED"
console.log(status.transactionId); // "PAY-BANK-001"
console.log(status.referenceId);   // "STA-100000000143"
console.log(status.amount);        // 100
console.log(status.fee);           // 0
```

### Account Balance

```typescript
const balance = await client.disbursement.balance();

console.log(balance.data);
// { wallets: [{ currency: "USD", balance: "1000.00" }] }
```

### Bank Codes

Retrieve the list of banks and mobile money providers for a country. Use the `payangelCode` from the response as the `bankCode` when sending money.

```typescript
const codes = await client.disbursement.bankCodes({ country: "GH" });

// Banks
codes.data?.banks.forEach((bank) => {
  console.log(bank.payangelCode, bank.name);
  // "170100" "FIRST ATLANTIC BANK"
  // "040100" "GCB BANK LTD"
  // "130100" "ECOBANK"
  // ...
});

// Mobile providers
codes.data?.mobileProviders.forEach((provider) => {
  console.log(provider.payangelCode, provider.name);
  // "23304" "MTN"
  // "23302" "TELECEL"
  // "23301" "AIRTEL TIGO"
  // ...
});
```

### Name Check

Verify an account holder's name before sending money.

```typescript
const check = await client.disbursement.nameCheck({
  country: "GH",
  accountNumber: "1775702701014",
  payangelCode: "170100",        // from bankCodes()
  accountType: "bank",           // "bank" or "mobile"
});

console.log(check.success); // true
console.log(check.name);    // "JANE MENSAH"
```

---

## Collection

### Mobile Money Collection

Initiate a MOMO payment prompt on the customer's phone.

```typescript
const result = await client.collection.mobileMoney({
  mobileNetwork: "mtn",                        // normalised automatically
  ipAddress: "154.160.2.56",                    // customer's IP address
  transactionId: "COLL-MOMO-001",              // your unique ID
  country: "GH",
  amount: 5,
  customerAccount: "233541348180",              // must include country code
  currency: "GHS",
  itemDescription: "Order #1042",
  callbackUrl: "https://yourserver.com/webhooks/payangel",
});

// result.success       → true
// result.transactionId → "COLL-MOMO-001"
// result.referenceId   → "STA-100000000148"
// result.status        → "PENDING"
// result.amount        → 5
// result.currency      → "GHS"
```

The customer will receive a MOMO prompt on their phone. After they approve or reject, PayAngel sends a webhook to your `callbackUrl`.

### Card Collection

Initiate a card payment. The response may contain a payment URL to redirect the customer to.

```typescript
const result = await client.collection.card({
  transactionId: "COLL-CARD-001",
  country: "GH",
  customerAccount: "customer@example.com",      // customer email
  currency: "GHS",
  amount: 100,
  itemDescription: "Premium subscription",
  redirectUrl: "https://yoursite.com/payment/complete",
});
```

### Collection Status

Check the status of a collection transaction.

```typescript
const status = await client.collection.status("COLL-MOMO-001");

console.log(status.success);        // true
console.log(status.status);         // "SUCCESS" | "PENDING" | "FAILED"
console.log(status.raw?.message);   // "The operation was successful"
```

---

## Webhooks

Verify webhook signatures using HMAC-SHA256. This is a static method — no client instance needed.

```typescript
import { PayAngel, WebhookSignatureError } from "payangel";

// Express example
// IMPORTANT: use express.raw() to get the raw body, NOT express.json()
app.post(
  "/webhooks/payangel",
  express.raw({ type: "application/json" }),
  (req, res) => {
    try {
      const event = PayAngel.webhooks.verify(
        req.body,                                       // raw Buffer
        req.headers["x-payangel-signature"] as string,  // HMAC-SHA256 hex
        process.env.PAYANGEL_WEBHOOK_SECRET!,
      );

      switch (event.type) {
        case "disbursement.completed":
          console.log("Payment completed:", event.data.transactionId);
          console.log("Amount:", event.data.amount, event.data.currency);
          break;
        case "disbursement.failed":
          console.log("Payment failed:", event.data.failureReason);
          break;
        case "disbursement.processing":
          console.log("Payment processing:", event.data.transactionId);
          break;
      }

      res.sendStatus(200);
    } catch (err) {
      if (err instanceof WebhookSignatureError) {
        console.error("Invalid signature");
        res.sendStatus(401);
      } else {
        res.sendStatus(500);
      }
    }
  },
);
```

### Alternative import

```typescript
import { webhooks } from "payangel";
const event = webhooks.verify(rawBody, signature, secret);
```

### Next.js App Router example

```typescript
import { NextRequest, NextResponse } from "next/server";
import { PayAngel, WebhookSignatureError } from "payangel";

export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("x-payangel-signature") ?? "";

  try {
    const event = PayAngel.webhooks.verify(
      body,
      signature,
      process.env.PAYANGEL_WEBHOOK_SECRET!,
    );
    // Handle event...
    return NextResponse.json({ received: true });
  } catch (err) {
    if (err instanceof WebhookSignatureError) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
    }
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}
```

### Webhook event types

| Event | Description |
|---|---|
| `disbursement.pending` | Transaction created, awaiting processing |
| `disbursement.processing` | Transaction is being processed |
| `disbursement.completed` | Transaction completed successfully |
| `disbursement.failed` | Transaction failed |
| `disbursement.cancelled` | Transaction was cancelled |

### Webhook event data

```typescript
{
  type: "disbursement.completed",
  data: {
    transactionId: "PAY-001",
    reference: "STA-100000000143",
    status: "COMPLETED",
    amount: 100,
    currency: "GHS",
    fee: 2,
    total: 102,
    createdAt: "2026-03-29T02:24:10.479Z",
    completedAt: "2026-03-29T02:25:30.000Z",
  },
  raw: { ... }  // original unmodified payload
}
```

> **Important:** You must use `express.raw()` (not `express.json()`) for the webhook route. If the body is already parsed as JSON, the HMAC signature verification will fail.

---

## Error Handling

All errors extend `PayAngelError` and include structured metadata for programmatic handling.

```typescript
import {
  PayAngelError,
  AuthenticationError,
  InvalidRequestError,
  RateLimitError,
  TransactionError,
  ServiceUnavailableError,
  WebhookSignatureError,
  APIError,
} from "payangel";

try {
  await client.disbursement.send({ ... });
} catch (err) {
  if (err instanceof AuthenticationError) {
    // 401/403 or E0014-098 (IP whitelist issue)
    console.error("Auth failed:", err.message);
    console.error("Code:", err.code);
  } else if (err instanceof InvalidRequestError) {
    // 400/422 — validation errors
    console.error("Validation:", err.message);
    console.error("Fields:", err.fields);
    // e.g. [{ field: "destinationAmount", message: "not valid" }]
  } else if (err instanceof RateLimitError) {
    // 429 — SDK auto-retries 3 times with exponential backoff
    console.error("Rate limited after retries");
  } else if (err instanceof TransactionError) {
    // Business logic error (E0016-xxx / V0016-xxx codes)
    console.error("Transaction error:", err.code, err.message);
  } else if (err instanceof ServiceUnavailableError) {
    // 500/503 — PayAngel is down
    console.error("Service down:", err.message);
  } else if (err instanceof PayAngelError) {
    // Catch-all for any other API error
    console.error("API error:", err.httpStatus, err.message);
  }
}
```

### Error class mapping

| HTTP Status | Error Code | Error Class |
|---|---|---|
| 401, 403 | - | `AuthenticationError` |
| - | `E0014-098` | `AuthenticationError` (IP whitelist) |
| 400, 422 | - | `InvalidRequestError` |
| 429 | - | `RateLimitError` |
| 500, 503 | - | `ServiceUnavailableError` |
| - | `E0016-xxx`, `V0016-xxx` | `TransactionError` |
| Other | - | `APIError` |

### Error properties

Every error includes:

| Property | Type | Description |
|---|---|---|
| `message` | `string` | Human-readable description |
| `httpStatus` | `number` | HTTP status code (0 for non-HTTP errors) |
| `code` | `string \| null` | PayAngel error code (e.g. `"E0016-007"`) |
| `fields` | `Array<{ field, message }>` | Per-field validation errors |
| `raw` | `unknown` | Original unmodified API response |

### Automatic retry

The SDK automatically retries on `429 Too Many Requests` with exponential backoff:

- Attempt 1: wait ~1s
- Attempt 2: wait ~2s
- Attempt 3: wait ~4s
- Attempt 4: throw `RateLimitError`

Each wait includes +/-20% random jitter to prevent thundering herd.

---

## Normalised Response

Every SDK method returns a consistent `PayAngelResponse<T>` shape, regardless of which API endpoint was called:

```typescript
interface PayAngelResponse<T> {
  success: boolean;            // was the request successful?
  transactionId: string | null;
  referenceId: string | null;
  status: TransactionStatus | null;
  amount: number | null;
  fee: number | null;
  total: number | null;
  currency: string | null;
  createdAt: string | null;
  data: T | null;              // typed payload specific to the method
  raw: unknown;                // original API response, unmodified
}
```

The raw PayAngel API returns three different envelope shapes. The SDK normalises all of them so you never have to deal with inconsistent responses:

```typescript
// Always the same shape, regardless of endpoint
const result = await client.disbursement.send({ ... });
console.log(result.success);       // boolean
console.log(result.transactionId); // string
console.log(result.raw);           // original API response if you need it
```

---

## TypeScript

Types are built in — **no need to install `@types/payangel`**.

All types are exported from the main package:

```typescript
import type {
  PayAngelConfig,
  PayAngelResponse,
  SendMoneyParams,
  MobileMoneyCollectionParams,
  CardCollectionParams,
  WebhookEvent,
  TransactionStatus,
  TransferType,
  CollectionType,
  Environment,
  MobileNetwork,
  DisbursementEvent,
  Wallet,
  BankCode,
  BankCodesResponse,
  NameCheckParams,
  NameCheckResult,
} from "payangel";
```

### Transaction statuses

```typescript
type TransactionStatus =
  | "PENDING"
  | "PROCESSING"
  | "COMPLETED"
  | "SUCCESS"
  | "FAILED"
  | "EXPIRED"
  | "RETRY";
```

---

## Important Notes

### `destinationAmount` is what the recipient gets

`destinationAmount` is the amount the **recipient receives** in `receivingCurrency`. This is NOT the amount debited from your PayAngel wallet.

```
Your wallet debit = destinationAmount + fee + FX spread
```

### `bankCode` = `payangelCode`

When calling `disbursement.send()` with `transferType: "bank"`, the `bankCode` field expects the `payangelCode` value returned by `disbursement.bankCodes()`. They have different names in different endpoints but are the same value.

```typescript
// Step 1: Get bank codes
const codes = await client.disbursement.bankCodes({ country: "GH" });
const firstAtlantic = codes.data?.banks.find(b => b.name.includes("FIRST ATLANTIC"));
// firstAtlantic.payangelCode → "170100"

// Step 2: Use payangelCode as bankCode
await client.disbursement.send({
  bankCode: firstAtlantic.payangelCode, // "170100"
  // ...
});
```

### `mobileNetwork` for mobile money disbursements

For `transferType: "mobile"`, pass the **network name** (e.g. `"MTN"`, `"mtn"`, `"Mtn"`) as `mobileNetwork`. Do NOT pass the `payangelCode`. The SDK normalises the casing automatically for each endpoint.

### `customerAccount` format for collection

When initiating a mobile money collection, `customerAccount` must include the country code:

```typescript
// Correct
customerAccount: "233541348180"  // 233 = Ghana country code

// Wrong
customerAccount: "0541348180"    // missing country code
```

### Callback URL

A `callbackUrl` is required for disbursement and collection requests. PayAngel sends webhook notifications to this URL when the transaction status changes.

---

## Known Limitations

| # | Question | Current SDK behaviour |
|---|----------|----------------------|
| 1 | Does Collection use `Basic` or `Bearer` auth? | Uses `Basic` (same as disbursement). One-line change if Bearer is needed. |
| 2 | Does per-request `callbackUrl` override portal URL? | Assumed yes (documented behaviour) |
| 3 | Does `Retry-After` header exist on 429 responses? | SDK uses fixed exponential backoff (1s, 2s, 4s) |

---

## License

MIT
